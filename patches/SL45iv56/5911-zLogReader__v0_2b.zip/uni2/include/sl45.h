#define sgn(a) ((a)>0?1:((a)<0?-1:0))
#define abs(a) ((a)>0?(a):(-a))

#define Heap0 ((void far*)0x039F4E)
#define malloc(a)       HeapMalloc(Heap0, (a))
#define free(a) HeapFree(Heap0, (a))
#define SystemFARHeap3 ((void far*)0x039EDA)

#define NULL    0x00000

typedef void far *LPVOID;
typedef LPVOID far *LPLPVOID;


//====================================================================================
// Strings
//====================================================================================
extern int sprintf( char far *, const char far *, ... );
extern int strlen(char far* Str);
extern char far* strcpy(char far* Str1, char far* Str2);
extern char* strchr(char far* Str1, int Char);
extern void StoreTextAsStringID( int ID, char far *Str, int UnknownFlag );
extern void ReplaceCharInStr(char far *Str, char c1, char c2);
extern void xsprintf(char far *, const char far *, ... );
extern void Word2DigitArray(int word, char far *str);

//====================================================================================
//������ � �����
//====================================================================================
struct _heap_
{
 void far *constr_data;
 void far *begin;
 unsigned int dummy;
 unsigned int free;
 void far *p2;
};

extern struct _heap_ *AllHeapsPointers[];

//extern void *FarMemAlloc(struct _heap_ far * _heap_pnt,unsigned int siz);
//extern void FarMemFree(struct _heap_ far * _heap_pnt,void far *mem);

struct PVARD
{
 struct _heap_ far ** pp_heap;
 unsigned int siz;
 char name[8];
};

//��������� ������ � ����
struct VAR_HEAP_HDR
{
 struct VAR_HEAP_HDR far * next;
 unsigned int siz;
 char name[8];
};

extern void *HeapMalloc(struct _heap_ far * _heap_pnt,unsigned int siz);
extern void HeapFree(struct _heap_ far * _heap_pnt,void far *mem);
extern char far* GetVars(const struct PVARD far *p);
extern void FreeVars(const struct PVARD far *p);

//====================================================================================
// ����������/���������� ������������
//====================================================================================
extern void AcquireGbsLock(void);
extern void FreeGbsLock(void);

//====================================================================================
//��������
//====================================================================================
extern int GBSS_po_open(const char far *name,int flag1, int flag2, int far *gbss_buf);
extern int GBSS_po_read(int handle, void far *buf, int bnum, int far *gbss_buf);
extern int GBSS_po_write(int handle, void far *buf, int bnum, int far *gbss_buf);
extern int GBSS_po_close(int handle, int far *gbss_buf);
extern int FileOpen(char far *name,int flag1,int flag2);
//oflag is an Integer constant combinations defined in FCNTL.H:
#define _O_RDONLY       0x0000  /* open for reading only */
#define _O_WRONLY       0x0001  /* open for writing only */
#define _O_RDWR         0x0002  /* open for reading and writing */
#define _O_APPEND       0x0008  /* writes done at eof */
#define _O_CREAT        0x0100  /* create and open file */
#define _O_TRUNC        0x0200  /* open and truncate */
#define _O_EXCL         0x0400  /* open only if file doesn't already exist */
#define _O_TEXT         0x4000  /* file mode is text (translated) */
#define _O_BINARY       0x8000  /* file mode is binary (untranslated) */
#define _O_NOINHERIT    0x0080  /* child process doesn't inherit file */
#define _O_TEMPORARY    0x0040  /* temporary file bit */
#define _O_SHORT_LIVED  0x1000  /* temporary storage file, try not to flush */
#define _O_SEQUENTIAL   0x0020  /* file access is primarily sequential */
#define _O_RANDOM       0x0010  /* file access is primarily random */
//The pmode argument is required only when _O_CREAT is specified.
//If the file already exists, pmode is ignored.
//Otherwise, pmode specifies the file permission settings,
//which are set when the new file is closed the first time.
#define _S_IREAD        0000400         /* read permission, owner */
#define _S_IWRITE       0000200         /* write permission, owner */
#define _S_IEXEC        0000100         /* execute/search permission, owner */
extern int FileSeek(int handle,long pos, int ref,long far *result);
//ref - 0 - from begin //1 - from current //2 - from end
extern int FileRead(int handle,void far *buf, int bnum);
extern int FileWrite(int handle,void far *buf, int bnum);
extern int FileClose(int handle);

//FAM3
extern void FilesysICall(void huge *proc);
extern const unsigned long FAM3_sig;
extern const unsigned int _binfile;


//====================================================================================
//EEPROM
//====================================================================================
extern void WriteEEPROMData(int Block, void far *Data,int Offset, int Size, int Zero1, int Zero2, int Zero3);
extern void ReadEEPROMData(int Block, void far *Data,int Offset, int Size, int Zero1, int Zero2, int Zero3);

//====================================================================================
//����
//====================================================================================
extern void PlayTone( int ID ); // 0 == stop playing


//====================================================================================
// �������
//====================================================================================
struct ImageHdr
{
 char W;
 char H;
 int Flags;      // 0x1
 void far* Ptr;
};

struct rectXYXY
{
 unsigned int X1;
 unsigned int Y1;
 unsigned int X2;
 unsigned int Y2;
};

typedef char far * STR;
typedef unsigned int far * WSTR;

extern struct ImageHdr far* GetBitmapResource(void far*Display,int ImageID);
extern void StoreImageAsImageID(int ImageID, struct ImageHdr far *Image, unsigned char far *ImageBuff);
extern void DrawImage(int x, int y, int width, int height, struct ImageHdr far* Image);
extern void DrawPredefinedImage(int x, int y, int ImageID);
extern void FillRect(int x,int y,int w,int h,int color); 
// fill styles
#define fill_white      0x0
#define fill_xor        0x1
#define fill_black      0x2
extern void ClearRect(int x,int y,int w,int h); 
extern void DrawString(int x,int y,int w,int h,const char far *str,int font);
// font types
#define font_4x7        0x0
#define wap_big         0x1
#define normal_big      0x2 //+bold
#define digit_4x7       0x4 //+bold
#define digit_5x5       0x6
#define normal          0x7 //+bold
#define wap             0x9
#define digit_big       0xA
#define bold            0x1 

extern STRtoWSTRP(WSTR *,STR);
extern DrawObject(void far *);
/*extern PrepDrawObj_type02(
 void far *drwobj,
 struct rectXYXY far *,
 unsigned int flag1,
 WSTR *,
 unsigned int font,
 unsigned int dat1,
 unsigned int flag2);*/

extern PrepDrawObj_type01(
 void far *drwobj,
 struct rectXYXY far *,
 //0x80 - ���. ����� ��� ������
 unsigned int flag1,
 WSTR *,
 unsigned int font,
 //0 - �� ����������, 1 - ����������
 unsigned int flag2);


//====================================================================================
// Dialogs
//====================================================================================
typedef int huge ButtonHandlerProc( int P1, int P2, int Key );
/* Key:
        for softkeys it is a ShortPressCode/LongPressCode, other keys:
        52 - button released or play button
        46 - record
        12 - "+" or up
        13 - "-" or down
        0c - green
        0a - red
        14 - left
        15 - long press left
        17 - right
        18 - long press right
        2e - numeric keys
        2F - * or #
*/
struct ButtonDef
{
        int ShortPressCode;     // code to return when this button pressed for a short period
        int LongPressCode;      // when pressed and held
        int TextId;                     // string ID from lng resources or -1 (no button), -2 (gray button)
};
// Window dialog with init and keyhndl

// struct DlgBuff Buff;
// ShowDialog((struct DlgHndl far*)&Struct,&Buff);
struct MSG
{
        void far *SenderPid;    // process which sent this MSG
        int Msg;
        int Param[6];
};

// kbd msg:
#define KEY_DOWN        0xE9
#define KEY_UP          0xEA 
#define LONG_PRESS      0xEB
// EC - sent 1 second after last key release, but not always?
// ED - ? unknown kbd msg
// EE - ? unknown kbd msg

// For kbd msg:
// P0 - scan Code:
#define LEFT_SOFT       0x01
#define RIGHT_SOFT      0x04
#define RECORD_BUTTON   0x06
#define GREEN_BUTTON    0x0B
#define RED_BUTTON      0x0C
#define VOL_UP_BUTTON   0x0D
#define VOL_DOWN_BUTTON 0x0E
#define UP_BUTTON       0x3B
#define DOWN_BUTTON     0x3C
#define LEFT_BUTTON     0x3D
#define RIGHT_BUTTON    0x3E
#define PLAY_BUTTON     0x3F
// '*', '#', '0'-'9'
// P1 - 0 or garbage
// P2 - scan code (if >80h, the key is releeased, if 7B - long press)
// P3 - 
// P4 - scan code with high byte == ??? or FF
// P5 - unknown

typedef void huge DlgOnKeyPress(void far* Unk, struct MSG far* Msg);

struct DlgHndl
{
 DlgOnKeyPress* onKeyPress;
 void huge* onInit;
 void huge* onExit1;
 void huge* onExit2;
 void huge* onRun;
 unsigned int buf_size1; //0x10 
 unsigned int dummy1;    //0xC4 
};

struct DlgBuff
{
 int Buff[15];
};

// MsgBox
struct MsgBoxData
{
        int Flag1;              // 4000 or 4003 or 0
        int Flag2;      // 0
        int Flag3;              // 22h - underlined caption, or 2 - not, 2000h - ???
        int TimeToKeep; // in milliseconds or 0 - infinite
        int unknown;    //0
        int DialogTitle;        // 7FFF - none
        void far *pNull1;       // 0
        ButtonHandlerProc *Handler;
        void far *pNull2;       // 0
        struct ButtonDef far *ButtonDefinitions;        // 4 ButtonDef's
        void far *pNull3;       // 0
};

extern void ShowDialog(const struct DlgHndl far*, struct DlgBuff far* Buff);
extern void ShowMessageDlg( struct MsgBoxData far* Struct, int far *StringIds );
extern void DoBack(int Unk); // 0xA - exit from dialog to previous screen


//====================================================================================
// �����
//====================================================================================
extern void OnTimer(unsigned long ms,void huge *);
extern void OnTimer1(void);
extern void OnTimer2(void);
extern void DisableTimer(void);

extern unsigned int _hour;
extern unsigned int _minute;
extern unsigned int _day;
extern unsigned int _month;
extern unsigned int _year;

//====================================================================================
// ������
//====================================================================================
extern void memcpy( void far*, void far*, unsigned int );
extern void *memset(void far *d,int what,int siz);
extern void *memcpyW(void far *d,const void far *s,unsigned long siz);




//====================================================================================
// Menus
//====================================================================================
extern void GeneralFunc(int Unk);
extern int DoEscape(void);

struct MENUHEADER
{
 int Unk1;
 int Unk2;
 int Unk3;
 int Unk4;
 char far* pMenuIconID;
 int header_string_ID;
 int end_of_data; // 0x7FFF
};

struct ITEMSDATA
{
 char far* pUnk1;
 int StringID1; // for big screen, and for normal screen 
 int StringID2; //
 int Zero1;
 char far* pUnk2;
 int ItemType;
 int ItemConditionCode;
};

struct ITEMSHNDL
{
 void huge* proc;
};

struct MENUSTRUCT
{
 void huge *pUnk1; //Unk1-Unk4 - handler_info
 void huge *pUnk2;
 void huge *pUnk3;
 void huge *pUnk4;
 char far* pUnkData1; 
 char far* pUnkData2;
 int Unk1;
 int Unk2;
 void huge* MenuHandler;   //button handler?
 struct ITEMSDATA far* ItemsData;
 struct ITEMSHNDL far* ItemsHandler;
 int ItemsCount;
};

#define menu_full       0x00
#define menu_options    0x01
extern void CreateMenu02(int Style, int Zero1, int Zero2, struct MENUSTRUCT far *, struct MENUHEADER far *, char far* Zero3,  char far* Zero4, void far* procZero5, char far* Zero6);

extern void SetMenuItemIcon(char far* Unk1, int Item, int Unk2, int Unk3);
extern void RefreshMenuItem(void);
extern int GetCurrentMenuItem(void);

//====================================================================================
// 
//====================================================================================
extern void doIDLE(void);


//1 - ���� �� �������������
extern int GetKeyLockState1(void);
extern void TurnLightON(void);
extern void pDialogOnRun(void);


#define HOOK_IDLE 0x10C60

extern char keybQueneIdx;
extern char keybQueneBuf[];
extern int GbsLock_ifNZ;
extern int GbsLock_ifZ;
extern void far *PidAct;

extern unsigned int NETMON_RX;
extern unsigned int NETMON_VB;
extern unsigned int NETMON_LS;
extern unsigned int NETMON_TB;
extern char NETMON_C1;
extern char NETMON_C2;


extern unsigned int NETMON_CI;
extern unsigned int NETMON_LAC;

struct CELLDATA
{
 unsigned int CH;
 unsigned int field2;
 unsigned int field4;
 unsigned int field6;
 unsigned int field8;
 unsigned char fieldA;
 unsigned char fieldB;
 unsigned int fieldC;
 unsigned int fieldE;
 unsigned int field10;
 unsigned int field12;
 unsigned int field14;
 unsigned int LAC;
 unsigned int CI;
};

extern struct CELLDATA far *CELL6_PNT[];
extern struct CELLDATA far *CURCELL_PNT;

extern struct
{
 unsigned int CH;
 unsigned char RXLVL;
 unsigned char C1;
 unsigned char C2;
 unsigned char N;
 unsigned char B;
 unsigned char dummy;
} NETMON7_TAB[7];

// 1 - 900
// 2 - 1800
// 3 - auto
extern void SetBAND(unsigned int band);
// ���������� ������� ������ � ������ ch
extern unsigned int GetRXLVL_by_CH(unsigned int ch);


extern unsigned int SMS_Unread;
extern unsigned int SMS_Free;

extern char GetProfileNum(void);
extern void TurnLightIfON(void);

extern int print(const char far *);

extern void CopyNumberToScreen(const char far * number);
