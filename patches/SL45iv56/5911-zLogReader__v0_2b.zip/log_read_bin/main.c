#include "reg167.h"
#include "..\uni2\include\sl45.h"

#define VERSION "0.2b"
#define NULL    0x00000

#define ram     0x82000

#define data0   0x84000
#define data1   0x88000
#define data2   0x8C000
#define data3   0x90000
#define data4   0x94000
#define data5   0x98000
#define data6   0x9C000


#include "images\bmp.h"

void rets(void);
void log_entries_Run(void);
void log_entries_OnKey(void far* Unk, struct MSG far* Msg);
void log_entries_Draw(void);
void menu_Run(void);
void menu_OnKey(void far* Unk, struct MSG far* Msg);
void menu_Draw(void);

static const struct DlgHndl far log_entries_hndl={log_entries_OnKey,rets,rets,rets,log_entries_Run,0x10,0xC4};
static const struct DlgHndl far menu_hndl={menu_OnKey,rets,rets,rets,menu_Run,0x10,0xC4};

static const char far s_O[]="Outgoing";
static const char far s_I[]="Incoming";
static const char far s_U[]="Unanswered";
static const char far s_S[]="SMS";
static const char far MENU_ENDING[]="--- End ---";
static const char far FILE_NAME[]="A:\\Misc\\xDyyyymm.log";

/*void NumberFunc1(void);
static const struct ITEMSDATA far itemsdata[2]=
{
 NULL,0x080A,0x080A,0,NULL,2,0x53A,
 NULL,0x080A,0x080A,0,NULL,2,0x53A
};
static const struct ITEMSHANDLER far itemshandler[2]={NumberFunc1,NumberFunc1};

static const struct MENUHEADER far menuheader=
{
 0x05,0x09,0x5F,0x15,NULL,0x2F5,0x7FFF
};
static const struct MENUSTRUCT far menustruct=
{
 NULL,NULL,NULL,NULL,
 (char far*)0xBAFC02,
 (char far*)0xBAFBFC,
 0x48,0,
 NULL,
 (struct ITEMSDATA far*)&itemsdata,
 (struct ITEMSHANDLER far*)&itemshandler,
 2};
*/
struct VARS
{
 char far   number[100];
 char far   file_name[22];
 char far** log_entries;
 int n_entries;
 int current;
 unsigned int month, year;
 char file_load; // 0 - loading file; 1 - load file; 2 - load file, draw screen;
 char show_entry;
 unsigned char pos_menu;
} far* const vars=(struct VARS far*)ram;


void main(void)
{
 struct DlgBuff Buff;
 memset(vars,0,sizeof(struct VARS));
 vars->log_entries=(char far**)(vars+sizeof(struct VARS));
 vars->month=_month;
 vars->year=_year;
 ShowDialog(&menu_hndl,&Buff);
}

void rets(void)
{
}

void StrToDialNumber(char far* in_number,char far* out_number)
{
 char i;
 char c0,c1;
 char s[100];
 char plus=0x81;

 strcpy(s,in_number);
 if (in_number[0]=='+') {
  plus+=0x10;
  strcpy(s,in_number+1);
 }
 memset(out_number,0x00,100);
 out_number[0]=0x06;
 out_number[1]=0x00;
 out_number[2]=plus;
 out_number[3]=(strlen(s)+1)/2;
 out_number[4]=0x01;
 out_number[5]=0xFF;
 out_number[6]=0x00;
 for (i=0;i<out_number[3];i++)
 {
  c0=s[i*2]-0x30;
  if (s[i*2+1]!=0x00) c1=(s[i*2+1]-0x30)<<4;
  else c1=0xF0;
  out_number[7+i]=c1+c0;
 }
 out_number[7+out_number[3]]=0xFF;
}

void DrawWSTR(char far* s,const int x, const int y, const int font);

void NumberFunc1(void)
{
 char i;
 char far* buf=vars->number;
 char far* log_entry=vars->log_entries[vars->current];
 if (log_entry[0]=='-') return;
 strcpy(buf, log_entry+19);
 for (i=0;i<strlen(buf);i++) if (buf[i]==',' ){ buf[i]=0; break; }
 StrToDialNumber(buf,buf);
 CopyNumberToScreen(buf);
}

//========================================================================================

void DrawWSTR(char far* s,const int x, const int y, const int font)
{
 int i;
 WSTR u_pointer;
 unsigned int u_str[100];
 char dobj[0x1A]; 
 struct rectXYXY rc;
 rc.X1=x;
 rc.Y1=y;
 rc.X2=101;
 rc.Y2=y+10;
 u_pointer=u_str;
 STRtoWSTRP(&u_pointer,s);
 for (i=1;i<u_str[0]+1;i++)  // convert to russian unicode
  if (u_str[i]>=0x90 && u_str[i]<=0xD1) u_str[i]+=0x380;
 PrepDrawObj_type01(dobj,&rc,0x40,&u_pointer,font, 0); //0 - ����� ������ 0...11 
 DrawObject(dobj);
}

//========================================================================================

void log_entries(void)
{
 char n='C';
 char s[7];
 char far* buf=(char far*)&vars->file_name;
 struct DlgBuff Buff;
 vars->file_load=0;
 vars->show_entry=0;
 strcpy(buf,(char far*)&FILE_NAME);
 switch (vars->pos_menu)
 {
  case 0: n='C'; break;
  case 1: n='I'; break;
  case 2: n='U'; break;
  case 3: n='S'; break;
 }
 buf[8]=n;
 Word2DigitArray(vars->year,s);
 Word2DigitArray(vars->month,s+4);
 if (s[5]==0)
 {
  s[5]=s[4];
  s[4]='0';
 }
 for (n=0;n<6;n++)  buf[10+n]=s[n];
 ShowDialog(&log_entries_hndl,&Buff);
}

void load_log(void)
{
 char seg=0;
 long result;
 int f;
 int i, k=0, j=0;
 int n=1;//vars->n_entries, [0]=MENU_ENDING
 char *log_data=0;
 char far** log_entries=vars->log_entries;

 log_entries[0]=(char far*)&MENU_ENDING;
 f=FileOpen((char far*)&vars->file_name,_O_RDONLY,0);
 if (f!=-1)
 {
L1:
  switch (seg) 
  {
   case 0: log_data=(char far*)data0; break;
   case 1: log_data=(char far*)data1; break;
   case 2: log_data=(char far*)data2; break;
   case 3: log_data=(char far*)data3; break;
   case 4: log_data=(char far*)data4; break;
   case 5: log_data=(char far*)data5; break;
   case 6: log_data=(char far*)data6; break;
  };
  k=FileRead(f,log_data,0x4000);
  if (k!=0) {
   n++;
   log_entries[n-1]=log_data;
   for (i=0;i<k;i++)
   {
    if (log_data[i]==0x0A)
    {
     n++;
     log_data[i]=0x00;
     log_entries[n-1]=log_data+i+1;
         j=i+1;
    }
   }
   n--; // last str - blank
   if (k==0x4000) {
    seg++;
        FileSeek(f,-(0x4000-j),1,&result);
        goto L1;
   }
  }
  FileClose(f);
 }
 vars->n_entries=n;
 vars->current=n-1;
 vars->file_load=1;
}

//========================================================================================

void log_entries_Run(void) {
 ClearRect(0,0,101,80);
 DrawString(0,0,101,80,"LogReader bin v"VERSION"\nloading file...",normal);
 FilesysICall(load_log);
 OnTimer(100,log_entries_Draw);
 OnTimer1();
 OnTimer2();
}

void log_entries_OnKey(void far* Unk, struct MSG far* Msg) {
 int n=vars->n_entries;
 int cur=vars->current;
 char show_entry=vars->show_entry;
 char far** log_entries=vars->log_entries;

 if (vars->file_load!=2) return;
 if (Msg->Msg!=KEY_DOWN) 
 switch(Msg->Param[0]) {
  case VOL_DOWN_BUTTON:
                    if (show_entry) break;
                    cur-=7;
                    for (;cur<0; cur+=n) {}  // get a positive value with same division rest
                    cur%=n;
                    break;
  case VOL_UP_BUTTON:
                    if (show_entry) break;
                    cur+=7;
                    if (cur>=n) cur%=n;  // overflow, then count again
                    break;
  case DOWN_BUTTON:
                    cur--;
                    if (show_entry) if (cur==0) cur--;  // don't use first entry
                    if (cur<0) cur=n-1;
                    break;
  case UP_BUTTON:
                    cur++;
                    if (cur>=n) cur=0;
                    if (show_entry) if (cur==0) cur++;
                    break;
  case RECORD_BUTTON:
  case RED_BUTTON:
  case PLAY_BUTTON:
  case LEFT_BUTTON:
                    if (!show_entry)
                    {
                     DoBack(0xA);
                     return;
                    }
                    else show_entry=!show_entry;
                    break;
  case RIGHT_SOFT:  // right softkey
  case RIGHT_BUTTON:// right key
                    if (log_entries[cur][0]!='-')
                     show_entry=!show_entry;
                    break;
  case GREEN_BUTTON:
  case LEFT_SOFT:
                    NumberFunc1();
//                    CreateMenu02(menu_options,0,0,(struct MENUSTRUCT far*)&menustruct,(struct MENUHEADER far*)&menuheader,0,0,0,0);
//                                        return;
  default:          return;
 };
 vars->current=cur;
 vars->show_entry=show_entry;
 log_entries_Draw();
 Unk=Unk;
}
//========================================================================================

struct ImageHdr far* GetBMPType(char type)
{
 switch (type) {
  case 'O': // 'O'
           return (struct ImageHdr far*)&hdr_O;
  case 'I': // 'I'
           return (struct ImageHdr far*)&hdr_I;
  case 'U': // 'U'
           return (struct ImageHdr far*)&hdr_U;
  case 'S': // 'S'
           return (struct ImageHdr far*)&hdr_S;
  case 'D': // 'D'
           return (struct ImageHdr far*)&hdr_D;
  case 'R': // 'R'
           return (struct ImageHdr far *)&hdr_R;
 }
 return 0;
}

char far* GetStrType(char type)
{
 switch (type) {
  case 'O': // 'O'
           return (char far*)&s_O;
  case 'I': // 'I'
           return (char far*)&s_I;
  case 'U': // 'U'
           return (char far*)&s_U;
  case 'S': // 'S'
           return (char far*)&s_S;
  case 'D': // 'D'
           return (char far*)&s_S;
  case 'R': // 'R'
           return (char far*)&s_S;
 }
 return 0;
}

void showname(char far* log_entry, const int y) {
 struct ImageHdr far* bmp=0;
 char i,k;
 char number[20];
 char name[50];
 if (log_entry[0]=='-') {
  DrawWSTR(log_entry, 12, y, normal);
  return;
 }
 bmp=GetBMPType(log_entry[17]);
 if (bmp!=0) DrawImage(0, y-1, 10, 10, bmp);
 strcpy(number, log_entry+19);
 for (i=0;i<strlen(number);i++) if (number[i]==',' ){ number[i]=0; break; }
 k=20+strlen(number);
 for (i=k;i<strlen(log_entry);i++) if (log_entry[i]==',' ){ k=i+1; break; }
 strcpy(name, log_entry+k);
 if (name[0]!=0x0D) 
  DrawWSTR(name,12,y,normal);
 else
  DrawWSTR(number,12,y,normal);
}

void Draw_Entry(char far* log_entry)
{
 struct ImageHdr far* bmp;
 char i,k,j=0;
 char s[256];
 char far* type;
 FillRect(0,10,101,1,fill_black);
 FillRect(0,58,101,1,fill_black);
//time1
 strcpy(s, log_entry); s[16]=0;
 DrawWSTR(s,0,60,normal);
//type
 bmp=GetBMPType(log_entry[17]);
 type=GetStrType(log_entry[17]);
 if (bmp!=0) DrawImage(0, 0, 10, 10, bmp);
 DrawWSTR(type,12,0,normal+bold);
//number
 strcpy(s, log_entry+19);
 for (i=0;i<strlen(s);i++) if (s[i]==',' ){ s[i]=0; break; }
 k=20+strlen(s);
 DrawWSTR(s,0,20,normal+bold);
//time2
 for (i=k;i<strlen(log_entry);i++) if (log_entry[i]==',' ){ j=i+1; break; }
 if (j!=k+1)
 {
  strcpy(s,"Time: ");
  strcpy(s+6, log_entry+k); s[10]=0;
  DrawWSTR(s,0,70,normal);
 }
//name
 strcpy(s, log_entry+j);
 DrawWSTR(s,0,40,normal);
}

void log_entries_Draw(void)
{
 int cur=vars->current;
 int n=vars->n_entries;
 char far** log_entries=vars->log_entries;
 int i;
 if (vars->file_load==0) return;
 if (vars->file_load==1) {
  DisableTimer();
  vars->file_load=2;
 }
 ClearRect(0,0,101,80);
 if (!vars->show_entry)
 {
  DrawImage(0,70,101,10, (struct ImageHdr far *)&hdr_back);
  for (i=0; i<7; i++)
  {
   if (cur>2-i && cur<(n+3)- i) showname(log_entries[(cur-3)+i], 60-i*10);
   else if (n>6) showname(log_entries[(i>=4?-n:n)+cur+(i-3)], 60-i*10);
  }
  FillRect(11,29,101,10,fill_xor);
 } else {
  Draw_Entry(log_entries[cur]);
 }
}
//========================================================================================

void menu_Run(void)
{
 ClearRect(0,0,101,80);
 FillRect(0,10,101,1,fill_black);
 DrawImage(0,20,10,10,(struct ImageHdr far*)&hdr_O);
 DrawImage(0,30,10,10,(struct ImageHdr far*)&hdr_I);
 DrawImage(0,40,10,10,(struct ImageHdr far*)&hdr_U);
 DrawImage(0,50,10,10,(struct ImageHdr far*)&hdr_S);
 DrawImage(0,70,101,10, (struct ImageHdr far *)&hdr_back);
 menu_Draw();
}

void menu_OnKey(void far* Unk, struct MSG far* Msg)
{
 unsigned char pos_menu=vars->pos_menu;
 unsigned int month=vars->month;
 unsigned int year=vars->year;

 if (Msg->Msg!=KEY_DOWN) 
 switch(Msg->Param[0]) {
  case RECORD_BUTTON:
  case LEFT_BUTTON:
  case LEFT_SOFT:   
  case RED_BUTTON:
                    DoBack(0xA);
                    return;
  case VOL_DOWN_BUTTON:
  case DOWN_BUTTON:
                    pos_menu++;
                                        pos_menu%=4;
                                        break;
  case VOL_UP_BUTTON:
  case UP_BUTTON:
                    pos_menu--;
                                        if (pos_menu>3) pos_menu=3;
                                        break;
  case PLAY_BUTTON:
  case RIGHT_BUTTON:
  case RIGHT_SOFT:
                    log_entries();
                                        return;
  case '1':         
                    year--;
                                        break;
  case '4':         
                    year++;
                                        break;
  case '3':         
                    month--;
                                        if (month==0) {
                                         year--;
                                         month=12;
                                        }
                                        break;
  case '6':         
                    month++;
                                        if (month==13) {
                                         year++;
                                         month=1;
                                        }
                                        break;
  default:          return;
 };
 vars->pos_menu=pos_menu;
 vars->month=month;
 vars->year=year;
 menu_Draw();
 Unk=Unk;
}

void menu_Draw(void)
{
 char s[8];
 Word2DigitArray(vars->year,s);
 Word2DigitArray(vars->month,s+5);
 s[4]='/';
 DrawWSTR(s,0,0,normal);
 ClearRect(12,19,101,40);
 DrawWSTR((char far*)&s_O,12,20,normal);
 DrawWSTR((char far*)&s_I,12,30,normal);
 DrawWSTR((char far*)&s_U,12,40,normal);
 DrawWSTR((char far*)&s_S,12,50,normal);
 FillRect(12,19+vars->pos_menu*10,101,10,fill_xor);
}
