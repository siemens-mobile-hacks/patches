It's recovered version of snake, final version lost by hard disk crash((
For Siemems A60.

ILYA_ZX