typedef unsigned char byte;
void onredraw(void);
void drawbox(byte x0, byte y0, byte height, byte width, char color);
void drawmenu(byte mode);
void move_block();
void shift_block(int mode,int act,int shift);
void move_ball();
void AI();
void win();
void setgame(byte newgame);
void init();
void setpause();
void drawsym(char *out, char c);
void outtextxy(byte x, byte y, char* str);

