#include "c:\arm\inc\swilib.h"
char *msg=0;

__arm char *create_msg()
{
  char *fname = (char *)RamNameOfRecievedSendFile();
  msg=malloc(strlen(strrchr(fname,(int)'/') + 1)+16);
  sprintf(msg, "������� ����?\r\n%s", strrchr(fname,(int)'/') + 1);
  return msg;
}

__arm void clear_msg()
{
  if(msg)mfree(msg);
  msg=0;
}
