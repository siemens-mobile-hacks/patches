#include <swilib.h>

// "������� ����?\n" � UTF8
const char q[27] = {
  0xD0, 0x9F, 0xD1, 0x80, 0xD0, 0xB8, 0xD0, 0xBD,
  0xD1, 0x8F, 0xD1, 0x82, 0xD1, 0x8C, 0x20, 0xD1, 
  0x84, 0xD0, 0xB0, 0xD0, 0xB9, 0xD0, 0xBB, 0x3F,
  0x0A, 0x00
};

#pragma swi_number=0x8256
__swi __arm char *RamNameOfRecievedSendFile();

#pragma swi_number=0x2AA
__swi __arm int CreatePopupGUI_ws(int flag, void* user_pointer, void* desc, WSHDR *msg);

__arm int show_msg(int flag, void* p, void* desc)
{
  char* fname = strrchr(RamNameOfRecievedSendFile(), '/') + 1;
  char c_msg[256];
  memcpy(c_msg, q, sizeof(q));
  strncat((char*)c_msg,fname,256 - sizeof(q));
  
  WSHDR ws_msg;
  unsigned short ws_body[256];
  CreateLocalWS(&ws_msg,ws_body,256);
  utf8_2ws(&ws_msg, c_msg, 256);
  return CreatePopupGUI_ws(flag, p, desc, &ws_msg);
}
